﻿using ComputerCompany.Pages;
using System;
using System.Windows;

namespace ComputerCompany
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            fr_content.Navigate(new AuthoPage());
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            if (fr_content.CanGoBack)
                fr_content.GoBack();
        }

        private void fr_content_ContentRendered(object sender, EventArgs e)
        {
            btnBack.Visibility = fr_content.CanGoBack ? Visibility.Visible : Visibility.Hidden;
        }
    }
}