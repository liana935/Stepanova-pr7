﻿using ComputerCompany.Models;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace ComputerCompany.Pages
{
    public partial class ClientPage : Page
    {
        private users _currentUser;

        public ClientPage()
        {
            InitializeComponent();
            _currentUser = null;
            DisplayWelcomeMessage();
        }

        public ClientPage(users user)
        {
            InitializeComponent();
            _currentUser = user;
            DisplayWelcomeMessage();
        }

        private void DisplayWelcomeMessage()
        {
            if (_currentUser != null)
            {
                string userName = GetUserDisplayName();
                txtWelcome.Text = $"Добро пожаловать, {userName}!\nЛичный кабинет клиента";
            }
            else
            {
                txtWelcome.Text = "Вы вошли как гость";
            }
        }

        private string GetUserDisplayName()
        {
            if (_currentUser.id_clients.HasValue && _currentUser.clients != null)
            {
                return $"{_currentUser.clients.first_name} {_currentUser.clients.last_name}";
            }
            else if (_currentUser.id_employees.HasValue && _currentUser.employees != null)
            {
                return $"{_currentUser.employees.first_name} {_currentUser.employees.last_name}";
            }
            return _currentUser.login;
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AuthoPage());
        }
    }
}