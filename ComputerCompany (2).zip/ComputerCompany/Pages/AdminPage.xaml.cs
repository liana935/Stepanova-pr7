﻿using ComputerCompany.Models;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace ComputerCompany.Pages
{
    public partial class AdminPage : Page
    {
        private users _currentUser;

        public AdminPage()
        {
            InitializeComponent();
            _currentUser = null;
            DisplayWelcomeMessage();
        }

        public AdminPage(users user)
        {
            InitializeComponent();
            _currentUser = user;
            DisplayWelcomeMessage();
        }

        private void DisplayWelcomeMessage()
        {
            if (_currentUser != null)
            {
                string userName = GetUserDisplayName();
                txtWelcome.Text = $"Добро пожаловать, {userName}!\nВаша роль: Администратор";
            }
            else
            {
                txtWelcome.Text = "Панель администратора";
            }
        }

        private string GetUserDisplayName()
        {
            if (_currentUser.id_employees.HasValue && _currentUser.employees != null)
            {
                return $"{_currentUser.employees.first_name} {_currentUser.employees.last_name}";
            }
            return _currentUser.login;
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AuthoPage());
        }
    }
}