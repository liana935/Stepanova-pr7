﻿using ComputerCompany.Models;
using ComputerCompany.Services;
using System;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using System.Timers;

namespace ComputerCompany.Pages
{
    public partial class AuthoPage : Page
    {
        private int failedAttempts = 0;
        private const int MAX_ATTEMPTS = 3;
        private const int LOCKOUT_DURATION_SECONDS = 10;
        private string currentCaptcha;
        private pz5Entities1 db;

        // Для блокировки
        private bool isLockedOut = false;
        private int remainingLockoutSeconds;
        private Timer lockoutTimer;

        public AuthoPage()
        {
            InitializeComponent();
            db = new pz5Entities1();

            HideCaptchaElements();
            ClearAllFields();
            UpdateAttemptsCounter();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            // Фокусируемся на поле логина при загрузке страницы
            txtLogin.Focus();
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            // Очищаем таймер при уходе со страницы
            StopLockoutTimer();
            db?.Dispose();
        }

        private void ClearAllFields()
        {
            txtLogin.Text = "";
            txtPassword.Password = "";
            txtCaptcha.Text = "";
            failedAttempts = 0;
            HideCaptchaElements();
            UpdateAttemptsCounter();
        }

        private void HideCaptchaElements()
        {
            tblCaptcha.Visibility = Visibility.Collapsed;
            spCaptcha.Visibility = Visibility.Collapsed;
        }

        private void ShowCaptchaElements()
        {
            tblCaptcha.Visibility = Visibility.Visible;
            spCaptcha.Visibility = Visibility.Visible;
            GenerateCaptcha();
        }

        private void GenerateCaptcha()
        {
            currentCaptcha = CaptchaGenerator.GenerateCaptchaText(6);
            tblCaptcha.Text = $"Введите код: {currentCaptcha}";
            tblCaptcha.TextDecorations = TextDecorations.Strikethrough;
        }

        private void UpdateAttemptsCounter()
        {
            int remainingAttempts = MAX_ATTEMPTS - failedAttempts;
            if (remainingAttempts < 0) remainingAttempts = 0;

            tbAttemptsCounter.Text = $"Осталось попыток: {remainingAttempts}";

            // Меняем цвет на красный при последней попытке
            if (remainingAttempts <= 1)
            {
                tbAttemptsCounter.Foreground = System.Windows.Media.Brushes.Red;
            }
            else
            {
                tbAttemptsCounter.Foreground = System.Windows.Media.Brushes.Gray;
            }
        }

        private void EnableControls(bool enable)
        {
            txtLogin.IsEnabled = enable;
            txtPassword.IsEnabled = enable;
            txtCaptcha.IsEnabled = enable;
            btnRefreshCaptcha.IsEnabled = enable;
            btnEnter.IsEnabled = enable;
        }

        private void StopLockoutTimer()
        {
            if (lockoutTimer != null)
            {
                lockoutTimer.Stop();
                lockoutTimer.Dispose();
                lockoutTimer = null;
            }
        }

        private void StartLockout()
        {
            isLockedOut = true;
            remainingLockoutSeconds = LOCKOUT_DURATION_SECONDS;

            // Блокируем все элементы управления
            EnableControls(false);

            // Показываем таймер
            tbTimer.Visibility = Visibility.Visible;
            tbTimer.Text = $"Блокировка: {remainingLockoutSeconds} сек.";

            // Скрываем капчу при блокировке
            HideCaptchaElements();

            // Запускаем таймер
            StopLockoutTimer(); // Останавливаем предыдущий таймер, если был
            lockoutTimer = new Timer(1000); // Интервал 1 секунда
            lockoutTimer.Elapsed += LockoutTimer_Elapsed;
            lockoutTimer.AutoReset = true;
            lockoutTimer.Start();
        }

        private void LockoutTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            // Используем Dispatcher для обновления UI из другого потока
            Dispatcher.Invoke(() =>
            {
                remainingLockoutSeconds--;

                if (remainingLockoutSeconds <= 0)
                {
                    // Разблокируем
                    StopLockoutTimer();
                    UnlockControls();
                }
                else
                {
                    // Обновляем текст таймера
                    tbTimer.Text = $"Блокировка: {remainingLockoutSeconds} сек.";
                }
            });
        }

        private void UnlockControls()
        {
            isLockedOut = false;
            failedAttempts = 0;

            // Разблокируем элементы управления
            EnableControls(true);

            // Скрываем таймер
            tbTimer.Visibility = Visibility.Collapsed;

            // Скрываем капчу
            HideCaptchaElements();

            // Очищаем поля
            txtLogin.Clear();
            txtPassword.Password = "";
            txtCaptcha.Clear();

            // Обновляем счетчик
            UpdateAttemptsCounter();

            // Фокусируемся на поле логина
            txtLogin.Focus();
        }

        private void HandleFailedAttempt()
        {
            failedAttempts++;
            txtPassword.Password = "";
            UpdateAttemptsCounter();

            if (failedAttempts >= MAX_ATTEMPTS)
            {
                // Блокируем на 10 секунд при 3-й попытке
                StartLockout();
                MessageBox.Show($"Превышено количество попыток. Система заблокирована на {LOCKOUT_DURATION_SECONDS} секунд.",
                    "Блокировка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else if (failedAttempts == MAX_ATTEMPTS - 1)
            {
                // Показываем капчу при 2-й попытке
                ShowCaptchaElements();
                MessageBox.Show($"Неверный логин или пароль. Осталось попыток: {MAX_ATTEMPTS - failedAttempts}\n" +
                              "При следующей неудачной попытке система будет заблокирована на 10 секунд.",
                    "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {
                // При 1-й попытке просто показываем сообщение
                MessageBox.Show($"Неверный логин или пароль. Осталось попыток: {MAX_ATTEMPTS - failedAttempts}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Проверка блокировки
                if (isLockedOut)
                {
                    MessageBox.Show($"Система заблокирована. Подождите {remainingLockoutSeconds} секунд.",
                        "Блокировка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Проверка заполнения полей
                if (string.IsNullOrWhiteSpace(txtLogin.Text) ||
                    string.IsNullOrWhiteSpace(txtPassword.Password))
                {
                    MessageBox.Show("Введите логин и пароль", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                string login = txtLogin.Text;
                string plainPassword = txtPassword.Password;

                // Проверка капчи (если она активна)
                if (failedAttempts >= MAX_ATTEMPTS - 1 && spCaptcha.Visibility == Visibility.Visible)
                {
                    if (string.IsNullOrWhiteSpace(txtCaptcha.Text))
                    {
                        MessageBox.Show("Введите код с картинки", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    if (!txtCaptcha.Text.Equals(currentCaptcha, StringComparison.OrdinalIgnoreCase))
                    {
                        MessageBox.Show("Неверный код подтверждения", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Error);

                        GenerateCaptcha();
                        txtCaptcha.Clear();
                        HandleFailedAttempt();
                        return;
                    }
                }

                // Хешируем пароль и ищем пользователя
                string hashedInput = PasswordHasher.HashPassword(plainPassword);
                var user = db.users.FirstOrDefault(u =>
                    u.login == login &&
                    u.is_active == true);

                if (user != null)
                {
                    bool passwordMatches = user.password_hash.Equals(hashedInput, StringComparison.OrdinalIgnoreCase);

                    if (passwordMatches)
                    {
                        // Загружаем связанные данные
                        if (user.id_employees.HasValue)
                        {
                            db.Entry(user).Reference(u => u.employees).Load();
                        }
                        else if (user.id_clients.HasValue)
                        {
                            db.Entry(user).Reference(u => u.clients).Load();
                        }

                        // Успешная авторизация
                        LoginSuccess(user);
                        return;
                    }
                }

                // Неудачная попытка
                HandleFailedAttempt();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при авторизации: {ex.Message}\n\nПодробности: {ex.InnerException?.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoginSuccess(users user)
        {
            string roleDisplay = GetRoleDisplayName(user.role);
            string userName = GetUserDisplayName(user);

            MessageBox.Show($"Добро пожаловать, {userName}!\nВаша роль: {roleDisplay}",
                "Успешно", MessageBoxButton.OK, MessageBoxImage.Information);

            // Обновляем дату последнего входа
            user.last_login_date = DateTime.Now;
            db.SaveChanges();

            // Сбрасываем счетчик попыток
            failedAttempts = 0;

            // Останавливаем таймер, если он был активен
            StopLockoutTimer();

            // Переходим на страницу согласно роли
            NavigateToRolePage(user.role, user);
        }

        private string GetUserDisplayName(users user)
        {
            if (user.id_employees.HasValue && user.employees != null)
            {
                return $"{user.employees.first_name} {user.employees.last_name}";
            }
            else if (user.id_clients.HasValue && user.clients != null)
            {
                return $"{user.clients.first_name} {user.clients.last_name}";
            }
            else
            {
                return user.login;
            }
        }

        private string GetRoleDisplayName(string role)
        {
            switch (role?.ToLower())
            {
                case "admin": return "Администратор";
                case "manager": return "Менеджер";
                case "master": return "Инженер";
                case "specialist": return "Специалист";
                case "user": return "Клиент";
                default: return role ?? "Неизвестно";
            }
        }

        private void NavigateToRolePage(string role, users user)
        {
            try
            {
                switch (role?.ToLower())
                {
                    case "admin":
                        NavigationService.Navigate(new AdminPage(user));
                        break;
                    case "manager":
                        NavigationService.Navigate(new ManagerPage(user));
                        break;
                    case "master":
                        NavigationService.Navigate(new MasterPage(user));
                        break;
                    case "specialist":
                        NavigationService.Navigate(new SpecialistPage(user));
                        break;
                    case "user":
                        NavigationService.Navigate(new ClientPage(user));
                        break;
                    default:
                        NavigationService.Navigate(new ClientPage(user));
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при переходе: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnRefreshCaptcha_Click(object sender, RoutedEventArgs e)
        {
            if (!isLockedOut)
            {
                GenerateCaptcha();
                txtCaptcha.Clear();
            }
        }
    }
}